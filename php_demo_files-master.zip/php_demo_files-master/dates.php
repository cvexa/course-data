<?php 
date_default_timezone_set('Europe/Sofia');
echo date('H:i');