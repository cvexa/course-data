<?php 
include_once('includes/header.php');
?>
<div>
<?php
num_row(2,10);
	
	?>
	THE CONTENT
</div>
<?php 
include_once('includes/footer.php');
?>
	