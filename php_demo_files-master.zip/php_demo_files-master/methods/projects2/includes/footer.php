<footer>
	THE FOOTER
</footer>
</body>
</html>