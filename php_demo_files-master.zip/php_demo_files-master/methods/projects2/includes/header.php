<?php 
require_once('includes/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" type="text/css" href="">
</head>
<body>
<div>
<ul>
	NAVIGATION
</ul>	
</div>