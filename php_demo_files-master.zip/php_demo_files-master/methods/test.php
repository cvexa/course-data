<?php 
include_once('<functions class="php"></functions>');

num_row(1, 6);