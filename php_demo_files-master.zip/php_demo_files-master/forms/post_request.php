<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>post request</title>
</head>
<body>
	<form action="second.php" method="post">
		<textarea name="message">
			your message here
		</textarea>
		<textarea name="message1">
			your message here
		</textarea>
		<textarea name="message2">
			your message here
		</textarea>
		<input type="submit" name="submit" value="submit">
	</form>
</body>
</html>