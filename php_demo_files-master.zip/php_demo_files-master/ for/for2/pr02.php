<?php 

for ($i=20; $i <=40 ; $i+=2) { 
	echo $i." ";
}