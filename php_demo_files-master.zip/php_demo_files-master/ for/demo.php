<?php 
$num = 1;
for ($j=1; $j <=3 ; $j++) { 
	echo "<p>";
	for ($i=1; $i <=4 ; $i++) { 
		
		echo '$j ='.$j.', $i='.$i." ";
	}
	echo "</p>"; 
}


