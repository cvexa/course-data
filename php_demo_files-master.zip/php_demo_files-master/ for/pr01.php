<?php
//print numbers from 1-100, find the sum
$sum = 0;
for ($i=20; $i <=40; $i+=2) { 
	echo $i.' ';
	$sum+=$i;
}
