<?php 

echo "string";