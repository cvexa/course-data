<?php 

$a = 0;

if ($a % 2 == 0) {
	
	if ($a === 0 ) {
		echo "$a = 0";
		return;
	}
	echo '$a ='.$a." even";
}  else{
	echo '$a ='.$a." Odd";
}