<?php 
$var = 'o';

switch ($var) {
	case 'a':
	case 'e':
	case 'o':
	case 'u':
	case 'i':
	echo "Vocal";
	break;
	
	default:
		echo "consonant";
	break;
}