<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>triangle test</title>
</head>
<body>
	<form action="data_process.php" method="get">
		angle A
		<input type="text" name="angleA">
		angle B
		<input type="text" name="angleB">
		angle C
		<input type="text" name="angleC">
		<input type="submit" name="submit" value="check">
	</form>
	</body>
</html>