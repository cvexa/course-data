<?php 
echo "<pre>";
var_dump($_POST);
echo "</pre>";
$purchase = $_POST;
echo "<pre>";
var_dump($purchase);
echo "</pre>";

/*$sum = 0;
foreach ($purchase as $value) {
	$sum+=$value;
}
echo $sum;*/