<?php 
$user_data = array(	'first_name' 	=> "Venislav",
					'second_name' 	=> "Ivanov",
					'third_name' 	=> "Georgiev",
					'age'			=> 37,
					'profession'	=> "director" );
echo "<ul>";
echo "<li>first name - ".$user_data['first_name']."</li>";
echo "<li> second name - ".$user_data['second_name']."</li>";
echo "</ul>";