<?php 
echo "<pre>";
var_dump($_POST);
echo "</pre>";