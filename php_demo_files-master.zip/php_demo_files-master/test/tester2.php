<?php 

function print_name($param){
echo '<a href="http://'.$param.'" >'.$param.'</a>';
}

print_name('dir.bg');
print_name('bait.bg');