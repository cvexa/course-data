<?php 

$arr = array(1, 2, 3, 4);
$mult = 0;
echo "<ul>";
foreach ($arr as $value) {
	echo '<li>'.$mult += $value.'</li>';
	
}
echo "</ul>";

