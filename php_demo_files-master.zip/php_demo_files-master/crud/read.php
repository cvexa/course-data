<?php
//you can include the db connection code in separate file
//and include this file
$conn = mysqli_connect('localhost', 'root', '', 'hotels');

// if (!$conn) {
// 	die("Connection failed: " .mysqli_connect_error());
// 	} else {
// 	echo "Connected successfully !";
// 	}

$read_query = 	"SELECT * FROM cities 
				WHERE date_deleted IS NULL";

$read_result = mysqli_query($conn, $read_query);

//or table
echo "<ul>";
	if (mysqli_num_rows($read_result) > 0) {
		while($row = mysqli_fetch_assoc($read_result)){ 
		echo '<li>'.$row['city_name'];
		//for U D purpose we need update and delete buttons/links
		//we also need $row['id_city'] to know exactly which row of the table to 
		//update or to delete
		echo ' '.'<a href="update.php?id='.$row['id_city'].'">Edit</a>';
		echo ' '.'<a href="delete.php?id='.$row['id_city'].'">Delete</a>';

		echo '</li>';
		}
	}
echo "</ul>";
