<?php
$this ->load->view('templates/header');
$this->load->view($dynamic_view);
$this->load->view('templates/footer');

