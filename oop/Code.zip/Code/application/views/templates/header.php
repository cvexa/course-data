<!DOCTYPE html>
<html>
<head>
<title>Title of the document</title>
</head>