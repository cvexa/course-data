<?php

class Form extends CI_Controller{
	public function form(){
		$this->load->view('counter_view');
	}
}