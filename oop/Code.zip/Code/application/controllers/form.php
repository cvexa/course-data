<?php

class Form extends CI_Controller{
	public function form_view(){
		$this->load->view('login_form');
	}
	public function check(){
		
		$user_name = $this->input->post('user_name'); 
		$this->load->model('form_model');

		$result=$this->form_model->get_name($user_name);

		if ($result) {
			//session_start()
			//$_SESSION['username']=$user_name;
			$this->load->view('success');
		}else{
			$this->form_view();
		}

	}
}