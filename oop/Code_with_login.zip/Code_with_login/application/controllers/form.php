<?php

class Form extends CI_Controller{
	public function form_view(){
		$this->load->view('login_form');
	}
	public function check(){
		
		$user_name = $this->input->post('user_name');
		//echo "$user_name"; 
		$this->load->model('form_model');

		$result2=$this->form_model->get_name($user_name);
		// $result3=$this->form_model->get_first_name($user_name);

		if ($result2) {
			// session_destroy();
			// session_start();

			$this->load->library('session');
		
			$_SESSION['first_name']=$result2['first_name'];
			$_SESSION['username']=$result2['user_name'];
			$_SESSION['phone']=$result2['phone'];
			$_SESSION['photo']=$result2['photo'];


			$this->load->view('success');
		}else{
			$this->form_view();
		}


	}
		public function first(){
			// session_start();
			$this->load->library('session');
			$this->load->view('first_name');

		}	
}