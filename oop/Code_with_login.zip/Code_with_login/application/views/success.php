<?php
$user_name=$_SESSION['username'];
$first_name=$_SESSION['first_name'];
$phone=$_SESSION['phone'];

echo "hi"." ".$user_name;
echo "<a href='first'>GOGO</a>";
echo "<p>First name - ".$first_name."</p>";
