<?php

echo "<form action='form/check' method='post'>";
echo "<input type='text' name='user_name' placeholder='enter user name'>";
echo "<p><input type='password' name='password'></p>";
echo "<p><input type='submit' name='submit' value='go'></p>";
