<?php

$i = 1;
//var_dump($all_books);

echo '<table border="1">';
foreach($all_books as $key => $value)
{
echo "<tr><td>Number</td><td>Title : </td><td>Release date : </td><td>Author : </td></tr>";
echo "<tr>";
echo " <td>". $i++."</td>";
echo "<td>".$value['title']."</td>";
echo "<td>".$value['realease']."</td>";
echo "<td>".$value['name']."</td>";
echo "<td><a href='update_view/{$value['authors_id']}'>go</a></td>";
echo "</tr>";

}

