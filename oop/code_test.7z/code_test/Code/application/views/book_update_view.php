<?php
//$book_info
var_dump($author_info);

echo form_open('books/update/');
echo "<input type='hidden' name='author_id' value='{$value['authors_id']}'>";
echo "<p>Edit title:</p>";
echo "<input type='text' name='name' value='{$value['name']}'>";
//...............
echo "<input type='submit' name='submit' value='update'>";

echo form_close();