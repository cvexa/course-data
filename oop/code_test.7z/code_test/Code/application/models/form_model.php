<?php

class Form_model extends CI_Model{
	
}