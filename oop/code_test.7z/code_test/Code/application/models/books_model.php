<?php


class Books_model extends CI_Model{
	public function read_books(){
		$this->db->select();
		$this->db->from('titles');
		$this->db->join('authors', 'authors.authors_id = titles.authors_id');
		$this->db->join('types','types.types_id = titles.types_id');
		$q = $this->db->get();

        return $q->result_array();

	}
	public function update(){
		$authors_id = $this->input->post('authors_id');
		$data =array(	 
			'name' => $this->input->post('name'),
			// 'authors_id' => $this->input->post('authors_id'),
					);

		$this->db->update('authors', $data);
        $this->db->where('authors_id', $authors_id);
       

	}

	public function get_authors(){

			$this->db->select('*');
			$this->db->from('authors');
			$w = $this->db->get();

			return $w->result_array();
	}

	public function get_book_info($id){
		//gets book info by id
	}
}