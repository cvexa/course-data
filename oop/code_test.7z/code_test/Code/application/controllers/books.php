<?php

class Books extends CI_Controller{

	public function read(){
		$this->load->model('books_model');
		$data['all_books']=$this->books_model->read_books(); 
		$this->load->view('read_books',$data);
	}
	public function update_view($id){
		$this->load->model('books_model');
		// $data['book_info'] = $this->books_model->get_book_info($id);
		$data['author_info'] = $this->books_model->get_authors();


		$this->load->view('book_update_view', $data);
	
	}
	public function update($id){
		$this->load->model('books_model');
		$this->books_model->update($id); 

	}
}