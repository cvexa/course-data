<?php

class Form extends CI_Controller{
	public function forma(){
		$this->load->view('counter_view');
	}
}